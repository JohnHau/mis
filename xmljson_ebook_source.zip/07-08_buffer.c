#include <stdio.h>
#include <stdlib.h>
#include <libxml/parser.h>

int main()
{
	const char filename[] = "sample.xml";
	xmlDocPtr doc;
	xmlNodePtr root,newnode;
	const xmlChar *element = (const xmlChar *)"nemesis";
	const xmlChar *value = (const xmlChar *)"Underdog";
	xmlBufferPtr buffer;

	doc = xmlParseFile(filename);
	if( doc==NULL )
	{
		fprintf(stderr,"Unable to process %s\n",filename);
		exit(1);
	}

	root = xmlDocGetRootElement(doc);
	newnode = xmlNewTextChild( root, NULL, element, value );

	buffer = xmlBufferCreate();
	xmlNodeDump(buffer,doc,root,4,1);
	printf("%s\n",buffer->content);

	xmlFreeDoc(doc);

	return(0);
}
