#include <stdio.h>
#include <stdlib.h>
#include <libxml/parser.h>

int main()
{
	const xmlChar *r = (const xmlChar *)"root";
	const xmlChar *element = (const xmlChar *)"data";
	const xmlChar *value = (const xmlChar *)"Yes, I'm data!";
	xmlDocPtr doc;
	xmlNodePtr root,node;

	doc = xmlNewDoc( (const xmlChar *)"1.0");
	root = xmlNewDocNode( doc, NULL, r, NULL);
	xmlDocSetRootElement( doc, root );
	node = xmlNewTextChild( root, NULL, element, value);

	xmlSaveFormatFile( "new.xml", doc, 1 );

	xmlFreeDoc(doc);

	return(0);
}
