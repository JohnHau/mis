#include <stdio.h>
#include <stdlib.h>
#include <json-c/json.h>

int main()
{
	json_object *newobj,*newdata;
	const char b_name[] = "isReal";
	const char d_name[] = "iq";
	const char i_name[] = "age";
	const char n_name[] = "smell";
	const char s_value[] = "Arthur Grockmeister";
	const char s_name[] = "username";
	const char *jstring;

	newobj = json_object_new_object();
	if( newobj==NULL )
	{
		fprintf(stderr,"Unable to create object\n");
		exit(1);
	}
	puts("New object created:");

	/* bool */
	newdata = json_object_new_boolean( (json_bool)0 );
	json_object_object_add(newobj,b_name,newdata);
	/* double */
	newdata = json_object_new_double(212.0);
	json_object_object_add(newobj,d_name,newdata);
	/* int */
	newdata = json_object_new_int(59);
	json_object_object_add(newobj,i_name,newdata);
	/* null */
	json_object_object_add(newobj,n_name,NULL);
	/* string */
	newdata = json_object_new_string(s_value);
	json_object_object_add(newobj,s_name,newdata );

	jstring = json_object_to_json_string_ext(
			newobj,
			JSON_C_TO_STRING_PRETTY
			);
	puts(jstring);

	return(0);
}
