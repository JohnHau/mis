#include <stdio.h>
#include <stdlib.h>
#include <libxml/parser.h>

int main()
{
	const char filename[] = "sample.xml";
	xmlDocPtr doc;
	xmlNodePtr root;

	doc = xmlParseFile(filename);
	if( doc==NULL )
	{
		fprintf(stderr,"Unable to open %s\n",filename);
		exit(1);
	}

	root = xmlDocGetRootElement(doc);
	if( root->children )
		puts("The root node has children!");
	else
		puts("No children are available!");

	xmlFreeDoc(doc);

	return(0);
}
