#include <stdio.h>
#include <stdlib.h>
#include <json-c/json.h>

int main()
{
	json_object *newobj,*newdata;
	const char value[] = "Arthur Grockmeister";
	const char name[] = "username";
	const char *jstring;

	newobj = json_object_new_object();
	if( newobj==NULL )
	{
		fprintf(stderr,"Unable to create object\n");
		exit(1);
	}
	puts("New object created:");

	newdata = json_object_new_string(value);
	if( newdata==NULL )
	{
		fprintf(stderr,"Unable to create string object\n");
		exit(1);
	}

	json_object_object_add( newobj, name, newdata );
	jstring = json_object_to_json_string_ext(
			newobj,
			JSON_C_TO_STRING_PRETTY
			);
	puts(jstring);

	return(0);
}
