#include <stdio.h>
#include <stdlib.h>
#include <libxml/parser.h>

int main()
{
	const char filename[] = "new.xml";
	const xmlChar *r = (const xmlChar *)"root";
	const xmlChar *element = (const xmlChar *)"data";
	const xmlChar *value = (const xmlChar *)"Yes, I'm data!";
	xmlDocPtr doc;
	xmlNodePtr root,node;
	int x;

	doc = xmlNewDoc( (const xmlChar *)"1.0");
	root = xmlNewDocNode( doc, NULL, r, NULL);
	xmlDocSetRootElement( doc, root );
	node = xmlNewTextChild( root, NULL, element, value);

	x = xmlSaveFormatFileEnc( filename, doc, "UTF-8", 1 );
	if( x==-1 )
		printf("Unable to create %s\n",filename);
	else
		printf("%s created, %d bytes written\n",filename,x);

	xmlFreeDoc(doc);

	return(0);
}
