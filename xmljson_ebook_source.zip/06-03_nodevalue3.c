#include <stdio.h>
#include <stdlib.h>
#include <libxml/parser.h>

void ehunt(xmlDocPtr d,xmlNodePtr n,const xmlChar *c)
{
	xmlNodePtr cur;
	xmlChar *value;

	for(cur=n; cur; cur=cur->next)
	{
		if( !xmlStrcmp(cur->name,c) )
		{
			value = xmlNodeListGetString(d,cur->children,1);
			printf("<%s> is '%s'\n",cur->name,value);
			xmlFree(value);
			return;
		}
		if( cur->children )
			ehunt(d,cur->children,c);
	}
}

int main()
{
	const char filename[] = "sample.xml";
	xmlDocPtr doc;
	xmlNodePtr root;

	doc = xmlParseFile(filename);
	if( doc==NULL )
	{
		fprintf(stderr,"Unable to open %s\n",filename);
		exit(1);
	}

	root = xmlDocGetRootElement(doc);
	ehunt(doc,root,(const xmlChar *)"assistant");

	xmlFreeDoc(doc);

	return(0);
}
