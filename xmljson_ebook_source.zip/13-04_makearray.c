#include <stdio.h>
#include <stdlib.h>
#include <json-c/json.h>

int main()
{
	json_object *newobj,*jarray,*jelement;
	const char a_name[] = "hundreds";
	const char *jstring;
	int x;

	newobj = json_object_new_object();
	if( newobj==NULL )
	{
		fprintf(stderr,"Unable to create new object\n");
		exit(1);
	}
	puts("New object created:");

	jarray = json_object_new_array();
	if( jarray==NULL )
	{
		fprintf(stderr,"Unable to create array\n");
		exit(1);
	}

	for( x=100; x<901; x+=100 )
	{
		jelement = json_object_new_int(x);
		json_object_array_add( jarray, jelement );
	}
	json_object_object_add( newobj, a_name, jarray );

	jstring = json_object_to_json_string_ext(
			newobj,
			JSON_C_TO_STRING_PRETTY
			);
	puts(jstring);

	return(0);
}
