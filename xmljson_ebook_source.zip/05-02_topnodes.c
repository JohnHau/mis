#include <stdio.h>
#include <stdlib.h>
#include <libxml/parser.h>

int main()
{
	const char filename[] = "sample.xml";
	xmlDocPtr doc;
	xmlNodePtr root,node;

	doc = xmlParseFile(filename);
	if( doc==NULL )
	{
		fprintf(stderr,"Unable to open %s\n",filename);
		exit(1);
	}

	root = xmlDocGetRootElement(doc);
	for( node=root->children; node; node=node->next )
	{
		if( node->type==XML_ELEMENT_NODE )
			printf("%s\n",node->name);
	}

	xmlFreeDoc(doc);

	return(0);
}
