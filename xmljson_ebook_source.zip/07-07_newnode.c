#include <stdio.h>
#include <stdlib.h>
#include <libxml/parser.h>

int main()
{
	const char filename[] = "sample.xml";
	xmlDocPtr doc;
	xmlNodePtr root,newnode;
	const xmlChar *element = (const xmlChar *)"nemesis";
	const xmlChar *value = (const xmlChar *)"Underdog";

	doc = xmlParseFile(filename);
	if( doc==NULL )
	{
		fprintf(stderr,"Unable to process %s\n",filename);
		exit(1);
	}

	root = xmlDocGetRootElement(doc);
	newnode = xmlNewTextChild( root, NULL, element, value );
	xmlSaveFormatFile( "-", doc, 1 );

	xmlFreeDoc(doc);

	return(0);
}
