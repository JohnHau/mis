#include <stdio.h>
#include <stdlib.h>
#include <libxml/parser.h>

int main()
{
	const char filename[] = "sample.xml";
	xmlDocPtr doc;

	doc = xmlParseFile(filename);
	if( doc==NULL )
	{
		fprintf(stderr,"Unable to process %s\n",filename);
		exit(1);
	}
	printf("XML version is %s\n",doc->version);
	printf("XML encoding is %s\n",doc->encoding);

	xmlFreeDoc(doc);

	return(0);
}
