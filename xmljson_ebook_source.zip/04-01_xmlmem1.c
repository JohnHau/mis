#include <stdio.h>
#include <stdlib.h>
#include <libxml/parser.h>

int main()
{
	const char data[] = "<rootNode>\
						 <child>Baby1</child>\
						 </rootNode>";
	xmlDocPtr doc;

	doc = xmlParseMemory( data, sizeof(data) );
	if( doc==NULL)
	{
		fprintf(stderr,"Unable to parse data\n");
		xmlFreeDoc(doc);
		exit(1);
	}
	puts("Data parsed successfully");

	xmlFreeDoc(doc);

	return(0);
}
