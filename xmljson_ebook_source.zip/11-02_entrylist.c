#include <stdio.h>
#include <stdlib.h>
#include <json-c/json.h>

int main()
{
	const char filename[] = "sample.json";
	json_object *jdata;
	struct lh_entry *entry;
	char *key;

	jdata = json_object_from_file(filename);
	if( jdata==NULL )
	{
		fprintf(stderr,"Unable to process %s\n",filename);
		exit(1);
	}

	entry = json_object_get_object(jdata)->head;
	while( entry )
	{
		key = (char *)entry->k;
		printf("Object '%s' found\n",key);
		entry = entry->next;
	}

	return(0);
}
