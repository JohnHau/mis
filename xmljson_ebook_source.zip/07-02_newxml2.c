#include <stdio.h>
#include <stdlib.h>
#include <libxml/parser.h>

int main()
{
	const xmlChar *r = (const xmlChar *)"root";
	xmlDocPtr doc;
	xmlNodePtr root;

	doc = xmlNewDoc( (const xmlChar *)"1.0");
	root = xmlNewDocNode( doc, NULL, r, NULL);
	xmlDocSetRootElement( doc, root );

	xmlSaveFormatFile( "-", doc, 0 );

	xmlFreeDoc(doc);

	return(0);
}
