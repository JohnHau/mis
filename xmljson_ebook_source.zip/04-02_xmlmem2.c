#include <stdio.h>
#include <stdlib.h>
#include <libxml/parser.h>

int main()
{
	const char data[] = "<rootNode>\
						 <child>Baby1</child>\
						 </rootNode>";
	xmlDocPtr doc;
	xmlNodePtr root;

	doc = xmlParseMemory( data, sizeof(data) );

	root = xmlDocGetRootElement(doc);
	if( root==NULL)
	{
		fprintf(stderr,"Can't read data\n");
		xmlFreeDoc(doc);
		exit(1);
	}
	printf("Root node is '%s'\n",root->name);

	xmlFreeDoc(doc);

	return(0);
}
