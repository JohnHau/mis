#include <stdio.h>
#include <stdlib.h>
#include <json-c/json.h>

int main()
{
	const char filename[] = "sample.json";
	const char object_name[] = "assistant";
	json_object *jdata,*objname;

	jdata = json_object_from_file(filename);
	if( jdata==NULL )
	{
		fprintf(stderr,"Unable to process %s\n",filename);
		exit(1);
	}

	if( !json_object_object_get_ex(jdata,object_name,&objname))
	{
		fprintf(stderr,"Unable to find object '%s'\n",
				object_name);
		exit(1);
	}
	else
	{
		printf("Object '%s' found\n",object_name);
	}

	return(0);
}
