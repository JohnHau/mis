#include <stdio.h>
#include <stdlib.h>
#include <libxml/parser.h>

static void dump_elements(xmlNodePtr n)
{
	xmlNodePtr node;

	for( node=n; node; node=node->next )
	{
		if( node->type==XML_ELEMENT_NODE )
			printf("%s\n",node->name);
		if( node->children )
			dump_elements(node->children);
	}
}

int main()
{
	const char filename[] = "sample.xml";
	xmlDocPtr doc;
	xmlNodePtr root;

	doc = xmlParseFile(filename);
	if( doc==NULL )
	{
		fprintf(stderr,"Unable to open %s\n",filename);
		exit(1);
	}

	root = xmlDocGetRootElement(doc);
	dump_elements(root);

	xmlFreeDoc(doc);

	return(0);
}
