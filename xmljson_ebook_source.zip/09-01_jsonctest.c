#include <stdio.h>
#include <json-c/json.h>

int main()
{
	printf("json-c version %s\n",JSON_C_VERSION);

	return(0);
}
