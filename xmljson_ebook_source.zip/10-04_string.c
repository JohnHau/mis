#include <stdio.h>
#include <stdlib.h>
#include <json-c/json.h>

int main()
{
	const char jstring[] = "{\"table\":\"B2\",\"guests\":4,\
\"orders\":[ \"Steak MR\",\"Halibut\",\
\"Fettuccine\",\"Lobster\"]}";
	json_object *jdata;
	const char *string;

	jdata = json_tokener_parse(jstring);
	if( jdata==NULL )
	{
		fprintf(stderr,"Unable to tokenize string\n");
		exit(1);
	}
	string = json_object_to_json_string_ext(
			jdata,
			JSON_C_TO_STRING_PRETTY
			);
	puts(string);

	return(0);
}
