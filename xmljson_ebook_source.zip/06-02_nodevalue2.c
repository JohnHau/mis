#include <stdio.h>
#include <stdlib.h>
#include <libxml/parser.h>

int main()
{
	const char filename[] = "sample.xml";
	xmlDocPtr doc;
	xmlNodePtr root,node,cnode;
	xmlChar *value;

	doc = xmlParseFile(filename);
	if( doc==NULL )
	{
		fprintf(stderr,"Unable to open %s\n",filename);
		exit(1);
	}

	root = xmlDocGetRootElement(doc);
	node = root->children;
	while( node!=NULL )
	{
		if( !xmlStrcmp(node->name,(const xmlChar *)"address"))
		{
			cnode = node->children;
			while( cnode!=NULL )
			{
				if( !xmlStrcmp(
							cnode->name,
							(const xmlChar *)"street")
				  )
				{
					value = xmlNodeListGetString(
							doc,
							cnode->children,
							1
							);
					printf("Value of <%s> is '%s'\n",
							cnode->name,
							value
						  );
					xmlFree(value);
					break;
				}
				cnode = cnode->next;
			}
			break;
		}
		node = node->next;
	}

	xmlFreeDoc(doc);

	return(0);
}
