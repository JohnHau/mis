#include <stdio.h>
#include <libxml/xmlversion.h>

int main()
{
	printf("libxml2 version %d\n",LIBXML_VERSION);

	return(0);
}
