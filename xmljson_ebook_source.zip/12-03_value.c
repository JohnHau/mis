#include <stdio.h>
#include <stdlib.h>
#include <json-c/json.h>

int main()
{
	const char filename[] = "sample.json";
	const char name[] = "assistant";
	const char *value;
	json_object *jdata,*object;

	jdata = json_object_from_file(filename);
	if( jdata==NULL )
	{
		fprintf(stderr,"Unable to process %s\n",filename);
		exit(1);
	}

	json_object_object_get_ex(jdata,name,&object);
	value = json_object_get_string(object);
	printf("'%s''s value is %s\n",name,value);

	return(0);
}
