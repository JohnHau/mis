#include <stdio.h>
#include <stdlib.h>
#include <libxml/parser.h>

int main()
{
	xmlDocPtr doc;

	doc = xmlNewDoc( (const xmlChar *)"1.0");
	xmlSaveFormatFile( "-", doc, 0 );

	xmlFreeDoc(doc);

	return(0);
}
