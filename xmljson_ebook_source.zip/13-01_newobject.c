#include <stdio.h>
#include <stdlib.h>
#include <json-c/json.h>

int main()
{
	json_object *newobj;
	const char *jstring;

	newobj = json_object_new_object();
	if( newobj==NULL )
	{
		fprintf(stderr,"Unable to create object\n");
		exit(1);
	}
	puts("New object created:");
	jstring = json_object_to_json_string_ext(
			newobj,
			JSON_C_TO_STRING_PRETTY
			);
	puts(jstring);

	return(0);
}
