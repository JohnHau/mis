#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <curl/curl.h>

int main()
{
	char ftp[] = "ftp://127.0.0.0/file.pdf";
	CURL *curl;
	CURLcode r;
	FILE *fh;
	char filename[] = "file.pdf";

	/* open output file */
	fh = fopen( filename, "wb");
	if( fh==NULL)
	{
		fprintf(stderr,
				"Can't create %s\n",
				filename
			   );
		exit(1);
	}

	/* initialize curl */
	curl = curl_easy_init();
	
	printf("FTP...");
	/* set options for FPT fetch */
	curl_easy_setopt(curl,
			CURLOPT_URL, ftp);
	curl_easy_setopt(curl,
			CURLOPT_FOLLOWLOCATION, 1L);
	curl_easy_setopt(curl,
			CURLOPT_WRITEFUNCTION, NULL);
	curl_easy_setopt(curl,
			CURLOPT_WRITEDATA, fh);
	
	/* request-send upload */
	r = curl_easy_perform(curl);
	if( r!=CURLE_OK )
	{
		fprintf(stderr,"curl error: %s\n",
				curl_easy_strerror(r));
		fclose(fh);
		exit(1);
	}

	/* cleanup */
	curl_easy_cleanup(curl);
	fclose(fh);
	/* inform the user */
	printf("File '%s' written\n",filename);
	
	return(0);
}
