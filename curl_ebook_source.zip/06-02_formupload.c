#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <curl/curl.h>

static size_t read_callback(
	void *ptr,
	size_t size,
	size_t nmemb,
	void *userdata)
{
	FILE *local;
	size_t r;

	local = (FILE *)userdata;
	r = fread(ptr,size,nmemb,local);

	return(r);
}

int main()
{
	char address[] = "https://127.0.0.0/formsub.php";
	char file[] = "report.pdf";
	CURL *curl;
	CURLcode res;
	curl_mime *form = NULL;
	curl_mimepart *field = NULL;
	FILE *fp;

	/* open the file */
	fp = fopen( file, "rb");
	if( fp==NULL )
	{
		fprintf(stderr, "Unable to open %s\n", file);
		exit(1);
	}

	/* initialize curl */
	curl = curl_easy_init();
	
	/* create the form */
	form = curl_mime_init(curl);
		/* add the file field */
	field = curl_mime_addpart(form);
	curl_mime_name(field,"file");
	curl_mime_filedata(field,file);

	/* set curl options */
	curl_easy_setopt(curl, CURLOPT_MIMEPOST,form);
	curl_easy_setopt(curl, CURLOPT_READFUNCTION,
			read_callback);
	curl_easy_setopt(curl, CURLOPT_READDATA,fp);
	curl_easy_setopt(curl, CURLOPT_URL,address);

	/* send the form to the page */
	res = curl_easy_perform(curl);
	if( res!=CURLE_OK )
	{
		fprintf(stderr, "failed: %s\n",
				curl_easy_strerror(res));
		exit(1);
	}

	/* cleanup */
	curl_easy_cleanup(curl);
		/* release the form */
	curl_mime_free(form);
		/* and close the file */
	fclose(fp);

	return(0);
}
