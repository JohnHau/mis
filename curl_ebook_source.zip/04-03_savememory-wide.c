#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <curl/curl.h>

/* memory buffer structure */
struct web_data {
	char *buffer;
	size_t size;
};

/* callback function */
static size_t write_mem( void *ptr, size_t size, size_t nmemb, void *userdata)
{
	size_t realsize;
	struct web_data *mem;

	realsize = size * nmemb;
	mem = (struct web_data *)userdata;

	mem->buffer = realloc(mem->buffer, mem->size + realsize + 1);
	if( mem->buffer==NULL )
	{
		fprintf(stderr,"Memory error\n");
		exit(1);
	}

	memcpy( &(mem->buffer[mem->size]), ptr, realsize);
	mem->size += realsize;
	mem->buffer[mem->size] = 0;

	return(realsize);
}

int main()
{
	CURL *curl;
	CURLcode r;
	char address[] = "https://c-for-dummies.com/curl_test.txt";
	struct web_data page;

	/* initialize storage structure */
	page.buffer = malloc(1);
	if( page.buffer==NULL )
	{
		fprintf(stderr,"Memory error\n");
		exit(1);
	}
	page.size = 0;

	/* initialuze curl */
	curl = curl_easy_init();

	/* set options */
	curl_easy_setopt(curl, CURLOPT_URL,address);
	curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION,1L);
	curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION,write_mem);
	curl_easy_setopt(curl, CURLOPT_WRITEDATA,(void *)&page);
	
	/* read the address */
	r = curl_easy_perform(curl);
	if( r != CURLE_OK )
	{
		fprintf(stderr, "curl read failed: %s\n", curl_easy_strerror(r));
		exit(1);
	}
	
	/* cleanup */
	curl_easy_cleanup(curl);

	/* output results */
	printf("Read %ld bytes:\n", page.size);
	printf("%s",page.buffer);

	return(0);
}
