#include <stdio.h>
#include <curl/curl.h>

int main()
{
	curl_version_info_data *data;

	data = curl_version_info(CURLVERSION_NOW);
	printf("libcurl version %s\n", data->version);

	return(0);
}
