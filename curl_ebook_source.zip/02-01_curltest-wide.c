/* compile with the -lcurl switch to ensure that
   the libcurl library is linked in, verifying
   its installation.
   If the linker errors, set the -lcurl switch
   last */
#include <stdio.h>
#include <curl/curl.h>

int main()
{
	printf("libcurl version %s\n", LIBCURL_VERSION);

	return(0);
}
