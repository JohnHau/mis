#include <stdio.h>
#include <curl/curl.h>

int main()
{
	CURL *curl;
	char url[] =
		"https://c-for-dummies.com/curl_test.txt";

	curl = curl_easy_init();
	curl_easy_setopt(curl, CURLOPT_URL, url);
	curl_easy_perform(curl);
	curl_easy_cleanup(curl);

	return(0);
}
