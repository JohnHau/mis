#include <stdio.h>
#include <curl/curl.h>

int main()
{
	CURL *curl;
	char url[] = "https://c-for-dummies.com/curl_test.txt";

	/* Start the easy curl inteterface */
	curl = curl_easy_init();
		/* The curl variable (pointer) must be checked for
		   NULL at this point */

	/* Set easy curl options */
		/* Important is the address */
	curl_easy_setopt(curl, CURLOPT_URL, url);

	/* Send easy curl into action */
	curl_easy_perform(curl);
		/* output is generated automatically */

	/* Finish and cleanup */
	curl_easy_cleanup(curl);

	return(0);
}
