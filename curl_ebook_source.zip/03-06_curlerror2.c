#include <stdio.h>
#include <stdlib.h>
#include <curl/curl.h>

int main()
{
	CURL *curl;
	CURLcode res;
	char url[] = "odd://site.com";

	/* Initialize easy curl */
	curl = curl_easy_init();
	if( curl == NULL)
	{
		fprintf(stderr,"Unable to init\n");
		exit(1);
	}

	/* set options */
	curl_easy_setopt(curl, CURLOPT_URL, url);

	/* curl the resource */
	res = curl_easy_perform(curl);
	if( res!=CURLE_OK )
	{
		fprintf(stderr,"Can't curl %s\n",url);
		fprintf(stderr,"Error: %s\n",
				curl_easy_strerror(res)
			   );
		exit(1);
	}

	/* cleanup */
	curl_easy_cleanup(curl);

	return(0);
}
