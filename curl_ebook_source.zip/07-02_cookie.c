#include <stdio.h>
#include <stdlib.h>
#include <curl/curl.h>

int main()
{
	char address[] = "http://127.0.0.0/";
	char cookie[] = "username=dang";
	CURL *curl;
	CURLcode r;

	curl = curl_easy_init();
	if( curl==NULL )
	{
		fprintf(stderr,"Unable to curl\n");
		exit(1);
	}

	curl_easy_setopt(curl,CURLOPT_URL,address);
	curl_easy_setopt(curl,CURLOPT_COOKIE,cookie);

	r = curl_easy_perform(curl);
	if( r!=CURLE_OK)
	{
		fprintf(stderr,"Curl error: %s\n",
				curl_easy_strerror(r));
		exit(1);
	}

	curl_easy_cleanup(curl);
	puts("Cookies sent");
	return(0);
}
