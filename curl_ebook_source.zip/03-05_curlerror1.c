#include <stdio.h>
#include <stdlib.h>
#include <curl/curl.h>

int main()
{
	CURL *curl;
	CURLcode r;
	char url[] = "odd://site.com";
	char errbuff[CURL_ERROR_SIZE];

	/* Initialize easy curl */
	curl = curl_easy_init();
	if( curl == NULL)
	{
		fprintf(stderr,"Unable to init curl\n");
		exit(1);
	}

	/* set options */
	curl_easy_setopt(curl,CURLOPT_URL,url);
	curl_easy_setopt(curl,CURLOPT_ERRORBUFFER,errbuff);

	/* curl the resource */
	r = curl_easy_perform(curl);
	if( r!=CURLE_OK )
	{
		fprintf(stderr,"Can't curl %s\n",url);
		fprintf(stderr,"Error: %s\n",errbuff);
		exit(1);
	}

	/* cleanup */
	curl_easy_cleanup(curl);

	return(0);
}
