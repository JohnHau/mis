#include <stdio.h>
#include <stdlib.h>
#include <curl/curl.h>

int main()
{
	CURL *curl;
	char url[] = "https://c-for-dummies.com/curl_test.txt";

	/* initialize easy curl */
	curl = curl_easy_init();
	if(curl)
	{
		/* The 1L argumment means "on" */
		curl_easy_setopt(curl, CURLOPT_VERBOSE, 1L);
		curl_easy_setopt(curl, CURLOPT_URL, url);
		curl_easy_perform(curl);
		/* ensure that you do error-checking here */
		curl_easy_cleanup(curl);
	}

	return(0);
}
