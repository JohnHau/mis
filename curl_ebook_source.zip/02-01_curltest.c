#include <stdio.h>
#include <curl/curl.h>

int main()
{
	printf("libcurl version %s\n", LIBCURL_VERSION);

	return(0);
}
