#include <stdio.h>
#include <stdlib.h>
#include <curl/curl.h>

int main()
{
	/* bogus website */
	char address[] = "http://127.0.0.0/formsub.php";
	CURL *curl;
	CURLcode res;
	curl_mime *form = NULL;
	curl_mimepart *name_field = NULL;
	curl_mimepart *email_field = NULL;

	/* initialize curl */
	curl = curl_easy_init();
	
	/* create the form */
	form = curl_mime_init(curl);
		/* add the name field */
	name_field = curl_mime_addpart(form);
	curl_mime_name( name_field, "name");
	curl_mime_data( name_field, "George Washington", CURL_ZERO_TERMINATED);
		/* add the email field */
	email_field = curl_mime_addpart(form);
	curl_mime_name( email_field, "email");
	curl_mime_data( email_field, "gw@potus.gov", CURL_ZERO_TERMINATED);

	/* set curl options */
	curl_easy_setopt(curl, CURLOPT_MIMEPOST,form );
	curl_easy_setopt(curl, CURLOPT_URL,address );

	/* send the form to the page */
	res = curl_easy_perform(curl);
	if( res!=CURLE_OK )
	{
		fprintf(stderr, "Unable to upload form\n");
		exit(1);
	}

	/* cleanup */
	curl_easy_cleanup(curl);
		/* and release the form */
	curl_mime_free(form);

	return(0);
}
