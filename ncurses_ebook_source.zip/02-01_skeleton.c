#include <ncurses.h>

int main()
{
	initscr();	/* Initialize Ncurses */

	/* other programming */

	endwin();	/* close Ncurses */
	return(0);
}

