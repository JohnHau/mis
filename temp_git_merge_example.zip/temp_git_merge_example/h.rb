#!/usr/bin/env ruby
#prints out a greeting
def hello
<<<<<<< HEAD
  puts 'hello world==='
=======
  puts 'hello world=='
>>>>>>> whitespace
end

hello()
